// POST /api/upload
// Consumes the request body (draining it as fast as the network delivers) and
// reports how many bytes were received. The client times the round trip.

export async function onRequestPost({ request }) {
  let received = 0;
  if (request.body) {
    const reader = request.body.getReader();
    // eslint-disable-next-line no-constant-condition
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      received += value.byteLength;
    }
  }
  return new Response(JSON.stringify({ ok: true, bytes: received }), {
    headers: {
      'Content-Type': 'application/json',
      'Cache-Control': 'no-store',
    },
  });
}

// Cheap preflight/health for the same route.
export async function onRequestGet() {
  return new Response(JSON.stringify({ ok: true }), {
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
  });
}
