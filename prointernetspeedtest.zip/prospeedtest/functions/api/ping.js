// GET /api/ping — smallest possible round trip for latency + jitter sampling.
export async function onRequestGet() {
  return new Response('pong', {
    headers: {
      'Content-Type': 'text/plain',
      'Cache-Control': 'no-store, no-cache, must-revalidate',
    },
  });
}
