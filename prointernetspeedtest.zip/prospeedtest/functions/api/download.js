// GET /api/download?bytes=N
// Streams N bytes of incompressible data so the client can time throughput.
// Served as application/octet-stream (Cloudflare does not compress binary),
// with a single reused random chunk to keep Worker CPU minimal.

const MAX_BYTES = 100 * 1024 * 1024; // 100 MB hard cap per request
const CHUNK = 65536; // 64 KB

export async function onRequestGet({ request }) {
  const url = new URL(request.url);
  let bytes = parseInt(url.searchParams.get('bytes') || '10485760', 10);
  if (!Number.isFinite(bytes) || bytes < 0) bytes = 10485760;
  bytes = Math.min(bytes, MAX_BYTES);

  const seed = new Uint8Array(CHUNK);
  crypto.getRandomValues(seed);

  let remaining = bytes;
  const stream = new ReadableStream({
    pull(controller) {
      if (remaining <= 0) {
        controller.close();
        return;
      }
      const size = Math.min(CHUNK, remaining);
      controller.enqueue(size === CHUNK ? seed : seed.subarray(0, size));
      remaining -= size;
    },
  });

  return new Response(stream, {
    headers: {
      'Content-Type': 'application/octet-stream',
      'Content-Length': String(bytes),
      'Cache-Control': 'no-store, no-cache, must-revalidate',
      'Access-Control-Allow-Origin': 'self',
    },
  });
}
